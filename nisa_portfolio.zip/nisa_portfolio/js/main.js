// Initialize animations and interactivity
// Smooth scrolling for navigation links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});

// Add scroll-based animations
const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
};

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.style.opacity = '1';
            entry.target.style.transform = 'translateY(0)';
            
            // Add staggered animation for cards
            if (entry.target.classList.contains('project-card') || 
                entry.target.classList.contains('skill-item')) {
                const cards = entry.target.parentElement.children;
                Array.from(cards).forEach((card, index) => {
                    setTimeout(() => {
                        card.style.opacity = '1';
                        card.style.transform = 'translateY(0)';
                    }, index * 100);
                });
            }
        }
    });
}, observerOptions);

// Section observer for main sections
const sectionObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.classList.add('animate-in');
        }
    });
}, { threshold: 0.2 });

// Observe sections
document.querySelectorAll('.section').forEach(section => {
    sectionObserver.observe(section);
});

// Observe elements for animation
document.querySelectorAll('.project-card, .skill-item, .experience-item').forEach((el, index) => {
    el.style.opacity = '0';
    el.style.transform = 'translateY(20px)';
    el.style.transition = `opacity 0.6s ease ${index * 0.1}s, transform 0.6s ease ${index * 0.1}s`;
    observer.observe(el);
});

// Add parallax effect to hero shapes
window.addEventListener('scroll', () => {
    const scrolled = window.pageYOffset;
    const shapes = document.querySelectorAll('.shape');
    shapes.forEach((shape, index) => {
        const speed = 0.5 + (index * 0.1);
        shape.style.transform = `translateY(${scrolled * speed}px) rotate(${scrolled * 0.1}deg)`;
    });

    // Add navbar background on scroll
    const hero = document.querySelector('.hero');
    if (scrolled > 100) {
        hero.style.transform = `translateY(${scrolled * 0.1}px)`;
    }
});

// Add professional entrance animations for cards
const animateCards = () => {
    const cards = document.querySelectorAll('.project-card, .skill-item, .experience-item');
    cards.forEach((card, index) => {
        const rect = card.getBoundingClientRect();
        const isVisible = rect.top < window.innerHeight && rect.bottom > 0;
        
        if (isVisible && !card.classList.contains('animated')) {
            card.classList.add('animated');
            card.style.animation = `slideInFromLeft 0.8s ease-out ${index * 0.1}s both`;
            
            // Alternate animation direction
            if (index % 2 === 1) {
                card.style.animation = `slideInFromRight 0.8s ease-out ${index * 0.1}s both`;
            }
        }
    });
};

window.addEventListener('scroll', animateCards);
window.addEventListener('load', animateCards);